"""Import Books, Genres, and Publishers exports from CSV or XLSX into PostgreSQL."""

import argparse
import csv
import re
import sys
import unicodedata
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

from openpyxl import load_workbook
from sqlalchemy import delete, select

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.db import SessionLocal  # noqa: E402
from app.models import Book, Genre, Order, OrderItem, Publisher  # noqa: E402


ALIASES = {
    "id": ("id", "код", "ид", "идентификатор", "idжанра", "иджанра", "idиздателя", "идиздателя"),
    "name": ("name", "genrename", "publishername", "название", "наименование", "названиежанра", "названиеиздательства", "жанр", "издательство", "имя"),
    "title": ("title", "название", "наименование", "книга", "названиекниги"),
    "description": ("description", "описание", "описаниекниги", "аннотация"),
    "genre": ("genre", "жанр", "названиежанра", "жанркниги", "idжанра", "жанрид", "genreid"),
    "publisher": ("publisher", "издательство", "названиеиздательства", "publishername", "idиздателя", "publisherid"),
    "rating": ("rating", "рейтинг", "оценка"),
    "price": ("price", "стоимость", "цена", "ценаруб"),
    "publication_date": ("publicationdate", "датаиздания", "датапубликации", "годиздания", "год", "дата"),
    "stock": ("stock", "количество", "остаток", "колвонаскладе", "количествонаскладе"),
    "format": ("format", "формат", "тип", "электронная"),
}


def normalize_header(value: object) -> str:
    value = unicodedata.normalize("NFKC", str(value or "")).lower().replace("ё", "е")
    return re.sub(r"[^a-zа-я0-9]+", "", value)


def value_for(row: dict, field: str):
    normalized = {normalize_header(key): value for key, value in row.items()}
    for alias in ALIASES[field]:
        value = normalized.get(normalize_header(alias))
        if value is not None and str(value).strip():
            return value
    return None


def read_rows(path: Path) -> list[dict]:
    if not path.exists():
        raise FileNotFoundError(path)
    if path.suffix.lower() == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            sample = stream.read(4096)
            stream.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=";,\t,")
            except csv.Error:
                dialect = csv.excel
            return [row for row in csv.DictReader(stream, dialect=dialect) if any(str(v or "").strip() for v in row.values())]
    if path.suffix.lower() in {".xlsx", ".xlsm"}:
        workbook = load_workbook(path, read_only=True, data_only=True)
        sheet = workbook.active
        records = sheet.iter_rows(values_only=True)
        headers = next(records, ())
        return [dict(zip(headers, values)) for values in records if any(value is not None for value in values)]
    raise ValueError(f"Формат не поддерживается: {path.name}. Используйте CSV или XLSX.")


def parse_date(value) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value or "").strip()
    for pattern in ("%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y", "%Y/%m/%d", "%d-%m-%Y"):
        try:
            return datetime.strptime(text, pattern).date()
        except ValueError:
            pass
    if re.fullmatch(r"\d{4}", text):
        return date(int(text), 1, 1)
    raise ValueError(f"Не удалось распознать дату издания: {text!r}")


def parse_decimal(value, default: str | None = None) -> Decimal:
    text = str(value if value is not None else default or "").strip().replace(" ", "").replace("\u00a0", "").replace("₽", "").replace(",", ".")
    try:
        result = Decimal(text)
    except InvalidOperation:
        raise ValueError(f"Не удалось распознать число: {text!r}")
    if not result.is_finite() or result < 0:
        raise ValueError(f"Ожидалось неотрицательное число: {text!r}")
    return result


def resolve_name(value, by_id: dict, kind: str) -> str:
    text = str(value or "").strip()
    if text in by_id:
        text = by_id[text]
    if not text:
        raise ValueError(f"В строке книги не указано поле «{kind}».")
    return text


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--books", required=True, type=Path)
    parser.add_argument("--genres", required=True, type=Path)
    parser.add_argument("--publishers", required=True, type=Path)
    args = parser.parse_args()
    try:
        book_rows = read_rows(args.books)
        genre_rows = read_rows(args.genres)
        publisher_rows = read_rows(args.publishers)
        with SessionLocal.begin() as db:
            def import_reference(rows: list[dict], model) -> dict[str, str]:
                by_id = {}
                for row in rows:
                    name = value_for(row, "name")
                    if not name:
                        continue
                    name = str(name).strip()
                    entry = db.scalar(select(model).where(model.name == name))
                    if not entry:
                        entry = model(name=name)
                        db.add(entry)
                        db.flush()
                    source_id = value_for(row, "id")
                    if source_id is not None:
                        by_id[str(source_id).strip()] = name
                return by_id

            genre_ids = import_reference(genre_rows, Genre)
            publisher_ids = import_reference(publisher_rows, Publisher)
            # Remove only this app's marked demonstration records before loading real exports.
            demo_orders = db.scalars(select(Order).where(Order.order_number.like("BS-DEMO-%"))).all()
            demo_order_ids = [order.id for order in demo_orders]
            if demo_order_ids:
                db.execute(delete(OrderItem).where(OrderItem.order_id.in_(demo_order_ids)))
            for order in demo_orders:
                db.delete(order)
            demo_books = db.scalars(select(Book).where(Book.title.like("Демо: %"))).all()
            for book in demo_books:
                db.delete(book)
            db.flush()

            added = updated = 0
            for number, row in enumerate(book_rows, start=2):
                try:
                    title = value_for(row, "title")
                    if not title:
                        continue
                    genre_name = resolve_name(value_for(row, "genre"), genre_ids, "жанр")
                    publisher_name = resolve_name(value_for(row, "publisher"), publisher_ids, "издательство")
                    genre = db.scalar(select(Genre).where(Genre.name == genre_name))
                    if not genre:
                        genre = Genre(name=genre_name)
                        db.add(genre)
                        db.flush()
                    publisher = db.scalar(select(Publisher).where(Publisher.name == publisher_name))
                    if not publisher:
                        publisher = Publisher(name=publisher_name)
                        db.add(publisher)
                        db.flush()
                    raw_format = normalize_header(value_for(row, "format"))
                    book_format = "ebook" if raw_format in {"ebook", "электронная", "электроннаякнига", "цифровая", "цифровой", "да", "1", "true", "истина"} else "print"
                    record = {
                        "title": str(title).strip(),
                        "description": str(value_for(row, "description") or "").strip(),
                        "genre_id": genre.id,
                        "publisher_id": publisher.id,
                        "rating": parse_decimal(value_for(row, "rating"), "0"),
                        "price": parse_decimal(value_for(row, "price")),
                        "publication_date": parse_date(value_for(row, "publication_date")),
                        "stock": int(parse_decimal(value_for(row, "stock"), "0")),
                        "format": book_format,
                    }
                    if record["rating"] > 5:
                        raise ValueError("Рейтинг должен быть от 0 до 5")
                    raw_stock = parse_decimal(value_for(row, "stock"), "0")
                    if raw_stock != raw_stock.to_integral_value():
                        raise ValueError("Количество книг должно быть целым числом")
                    record["stock"] = int(raw_stock)
                    existing = db.scalar(select(Book).where(
                        Book.title == record["title"],
                        Book.publisher_id == publisher.id,
                        Book.publication_date == record["publication_date"],
                    ))
                    if existing:
                        for key, value in record.items():
                            setattr(existing, key, value)
                        updated += 1
                    else:
                        db.add(Book(**record))
                        added += 1
                except (ValueError, TypeError) as exc:
                    raise ValueError(f"Строка {number}: {exc}") from exc
        print(f"Импорт завершён: добавлено {added}, обновлено {updated}.")
        return 0
    except (OSError, ValueError) as exc:
        print(f"Ошибка импорта: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
