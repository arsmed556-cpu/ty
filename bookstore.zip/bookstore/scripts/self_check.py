from datetime import date
from decimal import Decimal
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.main import parse_book_values
from app.security import hash_password, verify_password
from scripts.import_legacy import normalize_header, parse_date, parse_decimal


password_hash = hash_password("correct horse battery staple")
assert verify_password("correct horse battery staple", password_hash)
assert not verify_password("wrong password", password_hash)
assert normalize_header("Дата издания") == "датаиздания"
assert parse_date("11.10.2026") == date(2026, 10, 11)
assert parse_decimal("1 299,50 ₽") == Decimal("1299.50")

book = parse_book_values("Книга", "Описание", 1, 1, "4,5", "125.50", "2026-10-11", 2, "print")
assert book["rating"] == Decimal("4.5") and book["price"] == Decimal("125.50")
for bad_price, bad_stock in (("-1", 0), ("10", -1)):
    try:
        parse_book_values("Книга", "", 1, 1, "4", bad_price, "2026-10-11", bad_stock, "print")
        raise AssertionError("Negative price or stock must be rejected")
    except ValueError:
        pass
print("Self-check passed.")
