from pathlib import Path

from reportlab.lib.colors import HexColor, white
from reportlab.lib.pagesizes import A3, landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output" / "bookstore_diagrams.pdf"
PAGE = landscape(A3)
W, H = PAGE
GREEN = HexColor("#2c674d")
DARK = HexColor("#252821")
MUTED = HexColor("#77796f")
LINE = HexColor("#d9d6cc")
PAPER = HexColor("#f8f7f2")
PALE_GREEN = HexColor("#e8efe6")
PALE_RED = HexColor("#fff0ed")
RED = HexColor("#b93e32")


def register_fonts() -> tuple[str, str]:
    fonts_dir = Path("C:/Windows/Fonts")
    regular = fonts_dir / "arial.ttf"
    bold = fonts_dir / "arialbd.ttf"
    if not regular.exists():
        raise FileNotFoundError("Arial TTF is required to render Cyrillic labels in the PDF.")
    pdfmetrics.registerFont(TTFont("BookArial", str(regular)))
    if bold.exists():
        pdfmetrics.registerFont(TTFont("BookArialBold", str(bold)))
        return "BookArial", "BookArialBold"
    return "BookArial", "BookArial"


REGULAR, BOLD = register_fonts()


def background(c: canvas.Canvas, title: str, subtitle: str, page: str) -> None:
    c.setFillColor(PAPER)
    c.rect(0, 0, W, H, fill=1, stroke=0)
    c.setFillColor(GREEN)
    c.roundRect(40, H - 45, 8, 27, 4, fill=1, stroke=0)
    c.setFillColor(DARK)
    c.setFont(BOLD, 18)
    c.drawString(60, H - 36, title)
    c.setFillColor(MUTED)
    c.setFont(REGULAR, 9)
    c.drawString(60, H - 55, subtitle)
    c.setStrokeColor(LINE)
    c.line(40, H - 69, W - 40, H - 69)
    c.setFont(REGULAR, 8)
    c.drawRightString(W - 40, 24, f"BookStore · {page}")


def centered_lines(c: canvas.Canvas, lines: list[str], x: float, y: float, font: str = REGULAR, size: int = 9, leading: int = 12, color=DARK) -> None:
    c.setFillColor(color)
    c.setFont(font, size)
    start = y + (len(lines) - 1) * leading / 2
    for index, line in enumerate(lines):
        c.drawCentredString(x, start - index * leading, line)


def draw_arrow_head(c: canvas.Canvas, x1: float, y1: float, x2: float, y2: float, color=GREEN) -> None:
    import math

    angle = math.atan2(y2 - y1, x2 - x1)
    size, spread = 7, 0.48
    p1 = (x2, y2)
    p2 = (x2 - size * math.cos(angle - spread), y2 - size * math.sin(angle - spread))
    p3 = (x2 - size * math.cos(angle + spread), y2 - size * math.sin(angle + spread))
    c.setFillColor(color)
    path = c.beginPath()
    path.moveTo(*p1)
    path.lineTo(*p2)
    path.lineTo(*p3)
    path.close()
    c.drawPath(path, fill=1, stroke=0)


def arrow(c: canvas.Canvas, points: list[tuple[float, float]], color=GREEN, width=1.25) -> None:
    c.setStrokeColor(color)
    c.setLineWidth(width)
    for start, end in zip(points, points[1:]):
        c.line(start[0], start[1], end[0], end[1])
    draw_arrow_head(c, *points[-2], *points[-1], color=color)


def label(c: canvas.Canvas, text: str, x: float, y: float, color=GREEN) -> None:
    c.setFillColor(PAPER)
    c.roundRect(x - 13, y - 5, 26, 13, 4, fill=1, stroke=0)
    c.setFillColor(color)
    c.setFont(BOLD, 8)
    c.drawCentredString(x, y - 1, text)


def relation(c: canvas.Canvas, points: list[tuple[float, float]], one_at: tuple[float, float], many_at: tuple[float, float], route_label: str | None = None) -> None:
    arrow(c, points, color=GREEN)
    c.setFillColor(GREEN)
    c.setFont(BOLD, 8)
    c.drawCentredString(*one_at, "1")
    c.drawCentredString(*many_at, "N")
    if route_label:
        label(c, route_label, *points[len(points) // 2])


def entity(c: canvas.Canvas, name: str, fields: list[str], x: float, y: float, w: float, h: float) -> None:
    header_h = 25
    c.setFillColor(white)
    c.setStrokeColor(LINE)
    c.setLineWidth(1)
    c.roundRect(x, y, w, h, 8, fill=1, stroke=1)
    c.setFillColor(GREEN)
    c.roundRect(x, y + h - header_h, w, header_h, 8, fill=1, stroke=0)
    c.rect(x, y + h - header_h, w, 9, fill=1, stroke=0)
    c.setFillColor(white)
    c.setFont(BOLD, 10)
    c.drawString(x + 12, y + h - 17, name)
    row_h = min(15, (h - header_h - 8) / max(1, len(fields)))
    c.setFont(REGULAR, 8)
    for index, field in enumerate(fields):
        field_y = y + h - header_h - 14 - index * row_h
        if field.endswith("PK"):
            c.setFillColor(GREEN)
            c.setFont(BOLD, 8)
        else:
            c.setFillColor(DARK)
            c.setFont(REGULAR, 8)
        c.drawString(x + 12, field_y, field)


def er_page(c: canvas.Canvas) -> None:
    background(c, "Модель данных · 3НФ", "Справочники отделены от книг; заказ и его позиции связаны отдельными ключами.", "1 / 2")

    # Connectors are drawn before the entity cards so they remain behind the table shapes.
    relation(c, [(155, 570), (155, 520), (245, 455)], (155, 552), (234, 463))
    relation(c, [(415, 570), (415, 520), (442, 455)], (415, 552), (438, 463))
    relation(c, [(675, 570), (675, 455)], (675, 552), (675, 464))
    relation(c, [(820, 370), (880, 370)], (831, 380), (868, 380))
    relation(c, [(435, 275), (435, 230), (1015, 230), (1015, 295)], (445, 258), (1027, 302))

    entity(c, "genres · Жанры", ["id · PK", "name · UNIQUE"], 40, 570, 230, 135)
    entity(c, "publishers · Издатели", ["id · PK", "name · UNIQUE"], 300, 570, 230, 135)
    entity(c, "customers · Клиенты", ["id · PK", "full_name", "email", "phone"], 560, 570, 230, 135)
    entity(c, "users · Сотрудники", ["id · PK", "login · UNIQUE", "password_hash", "full_name", "role"], 820, 570, 330, 135)
    entity(c, "books · Книги", ["id · PK", "title", "description", "genre_id · FK", "publisher_id · FK", "rating", "price", "publication_date", "stock", "format", "cover_path"], 135, 275, 360, 185)
    entity(c, "orders · Заказы", ["id · PK", "order_number · UNIQUE", "placed_at", "delivery_date", "customer_id · FK", "status"], 550, 285, 270, 170)
    entity(c, "order_items · Состав заказа", ["order_id · PK/FK", "book_id · PK/FK", "quantity", "unit_price"], 880, 295, 270, 150)

    c.setFillColor(DARK)
    c.setFont(BOLD, 9)
    c.drawString(40, 145, "Связи")
    c.setFillColor(MUTED)
    c.setFont(REGULAR, 8)
    c.drawString(82, 145, "Жанр 1:N Книги · Издатель 1:N Книги · Клиент 1:N Заказы · Заказ 1:N Позиции · Книга 1:N Позиции")
    c.drawString(40, 125, "PK — первичный ключ   FK — внешний ключ   UNIQUE — уникальное значение   Цена в позиции заказа сохраняет цену на момент покупки.")
    c.drawString(40, 105, "Зависимые данные вынесены в отдельные сущности; неключевые поля зависят от ключа, всего ключа и ничего, кроме ключа.")
    c.showPage()


def terminator(c: canvas.Canvas, text: str, x: float, y: float, w: float, h: float) -> None:
    c.setFillColor(PALE_GREEN)
    c.setStrokeColor(GREEN)
    c.setLineWidth(1.3)
    c.roundRect(x, y, w, h, h / 2, fill=1, stroke=1)
    centered_lines(c, [text], x + w / 2, y + h / 2 - 3, BOLD, 9)


def process(c: canvas.Canvas, lines: list[str], x: float, y: float, w: float, h: float) -> None:
    c.setFillColor(white)
    c.setStrokeColor(GREEN)
    c.setLineWidth(1.2)
    c.rect(x, y, w, h, fill=1, stroke=1)
    centered_lines(c, lines, x + w / 2, y + h / 2 - 3, REGULAR, 9)


def io_symbol(c: canvas.Canvas, lines: list[str], x: float, y: float, w: float, h: float) -> None:
    slant = 13
    c.setFillColor(white)
    c.setStrokeColor(GREEN)
    c.setLineWidth(1.2)
    path = c.beginPath()
    path.moveTo(x + slant, y)
    path.lineTo(x + w, y)
    path.lineTo(x + w - slant, y + h)
    path.lineTo(x, y + h)
    path.close()
    c.drawPath(path, fill=1, stroke=1)
    centered_lines(c, lines, x + w / 2, y + h / 2 - 3, REGULAR, 9)


def decision(c: canvas.Canvas, lines: list[str], cx: float, cy: float, w: float, h: float) -> None:
    points = [(cx, cy + h / 2), (cx + w / 2, cy), (cx, cy - h / 2), (cx - w / 2, cy)]
    path = c.beginPath()
    path.moveTo(*points[0])
    for point in points[1:]:
        path.lineTo(*point)
    path.close()
    c.setFillColor(HexColor("#fffdf5"))
    c.setStrokeColor(GREEN)
    c.setLineWidth(1.2)
    c.drawPath(path, fill=1, stroke=1)
    centered_lines(c, lines, cx, cy - 3, REGULAR, 8, 10)


def flow_page(c: canvas.Canvas) -> None:
    background(c, "Алгоритм входа", "Блок-схема по ГОСТ 19.701-90 · гость получает только каталог для просмотра.", "2 / 2")

    # Main path
    arrow(c, [(590, 757), (590, 731)])
    arrow(c, [(590, 683), (590, 647)])
    arrow(c, [(590, 573), (590, 532)])
    arrow(c, [(590, 458), (590, 445)])
    arrow(c, [(590, 400), (590, 360)])
    arrow(c, [(590, 315), (590, 287)])
    arrow(c, [(590, 213), (590, 187)])
    arrow(c, [(590, 143), (590, 125)])
    arrow(c, [(590, 83), (590, 64)])

    # Guest branch
    arrow(c, [(685, 610), (820, 610)])
    arrow(c, [(945, 585), (945, 549)])

    # Error branches return to the credential input through a shared retry path.
    arrow(c, [(495, 495), (370, 495)])
    arrow(c, [(495, 250), (370, 250)])
    c.setStrokeColor(RED)
    c.setLineWidth(1.1)
    c.line(110, 490, 55, 490)
    c.line(110, 265, 55, 265)
    c.line(55, 265, 55, 490)
    c.line(55, 490, 55, 707)
    arrow(c, [(55, 707), (430, 707)], color=RED)

    terminator(c, "Начало", 510, 757, 160, 34)
    io_symbol(c, ["Ввести логин и пароль"], 430, 683, 320, 48)
    decision(c, ["Выбран режим", "гостя?"], 590, 610, 190, 74)
    decision(c, ["Логин и пароль", "заполнены?"], 590, 495, 190, 74)
    process(c, ["Найти учётную запись по логину"], 425, 400, 330, 45)
    process(c, ["Проверить пароль по сохранённому хэшу"], 425, 315, 330, 45)
    decision(c, ["Учётная запись найдена", "и пароль верен?"], 590, 250, 190, 74)
    process(c, ["Сохранить ФИО и роль в сессии"], 425, 143, 330, 44)
    io_symbol(c, ["Открыть интерфейс согласно роли"], 440, 83, 300, 42)
    terminator(c, "Конец", 520, 36, 140, 28)

    io_symbol(c, ["Открыть каталог", "только для просмотра"], 820, 585, 250, 50)
    terminator(c, "Каталог гостя", 870, 515, 150, 34)
    io_symbol(c, ["Показать сообщение:", "проверьте введённые данные"], 110, 465, 260, 52)
    io_symbol(c, ["Показать сообщение:", "неверный логин или пароль"], 110, 239, 260, 52)

    label(c, "Да", 738, 620)
    label(c, "Нет", 602, 546)
    label(c, "Нет", 430, 506, RED)
    label(c, "Да", 603, 451)
    label(c, "Нет", 430, 261, RED)
    label(c, "Да", 603, 202)
    c.setFillColor(RED)
    c.setFont(BOLD, 8)
    c.drawString(61, 604, "Повторить ввод")
    c.setFillColor(MUTED)
    c.setFont(REGULAR, 8)
    c.drawString(40, 20, "Овал — начало/конец · параллелограмм — ввод/вывод · прямоугольник — действие · ромб — условие.")
    c.showPage()


def main() -> None:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    c = canvas.Canvas(str(OUTPUT), pagesize=PAGE, pageCompression=1)
    c.setTitle("BookStore — ER-диаграмма и алгоритм авторизации")
    c.setAuthor("BookStore project")
    er_page(c)
    flow_page(c)
    c.save()
    print(OUTPUT)


if __name__ == "__main__":
    main()
