(() => {
  const grid = document.getElementById("bookGrid");
  const filters = document.getElementById("filters");
  if (grid && filters) {
    const search = document.getElementById("searchInput");
    const genre = document.getElementById("genreFilter");
    const sort = document.getElementById("dateSort");
    const stockOnly = document.getElementById("inStockFilter");
    const noResults = document.getElementById("noResults");
    const normalize = (value) => value.toLocaleLowerCase("ru").trim();
    const applyFilters = () => {
      const query = normalize(search.value);
      const cards = [...grid.querySelectorAll(".book-card")];
      cards.sort((a, b) => {
        const delta = a.dataset.publicationDate.localeCompare(b.dataset.publicationDate);
        return sort.value === "asc" ? delta : -delta;
      }).forEach((card) => grid.appendChild(card));
      let visible = 0;
      cards.forEach((card) => {
        const textMatch = `${card.dataset.title} ${card.dataset.description}`.includes(query);
        const genreMatch = !genre.value || card.dataset.genreId === genre.value;
        const stockMatch = !stockOnly.checked || Number(card.dataset.stock) > 0;
        card.hidden = !(textMatch && genreMatch && stockMatch);
        if (!card.hidden) visible += 1;
      });
      if (noResults) noResults.hidden = visible !== 0;
    };
    ["input", "change"].forEach((eventName) => {
      search.addEventListener(eventName, applyFilters);
      genre.addEventListener(eventName, applyFilters);
      sort.addEventListener(eventName, applyFilters);
      stockOnly.addEventListener(eventName, applyFilters);
    });
    applyFilters();
  }

  const dialog = document.getElementById("bookDialog");
  if (dialog) {
    const form = document.getElementById("bookForm");
    const title = document.getElementById("bookDialogTitle");
    document.getElementById("addBookButton").addEventListener("click", () => {
      form.reset();
      form.action = "/admin/books";
      title.textContent = "Новая книга";
      dialog.showModal();
    });
    document.querySelectorAll(".edit-book").forEach((button) => button.addEventListener("click", () => {
      const book = JSON.parse(button.dataset.book);
      form.reset();
      form.action = `/admin/books/${button.dataset.bookId}`;
      title.textContent = "Редактировать книгу";
      Object.entries(book).forEach(([key, value]) => {
        const inputName = key === "format" ? "book_format" : key;
        const field = form.elements.namedItem(inputName);
        if (field) field.value = value;
      });
      dialog.showModal();
    }));
    document.querySelectorAll(".dialog-close").forEach((button) => button.addEventListener("click", () => dialog.close()));
    dialog.addEventListener("click", (event) => {
      if (event.target === dialog) dialog.close();
    });
  }
})();
