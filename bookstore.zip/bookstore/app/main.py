import io
import os
import secrets
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from PIL import Image, UnidentifiedImageError
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload, selectinload
from starlette.middleware.sessions import SessionMiddleware

from .db import Base, SessionLocal, engine, get_db
from .models import Book, Customer, Genre, Order, OrderItem, Publisher, User
from .security import hash_password, valid_csrf, verify_password


APP_DIR = Path(__file__).resolve().parent
ROLES = {"seller": "Продавец", "manager": "Менеджер", "admin": "Администратор"}
ORDER_STATUSES = {
    "new": "Новый",
    "processing": "В обработке",
    "shipped": "Передан в доставку",
    "done": "Выполнен",
    "cancelled": "Отменён",
}
MAX_COVER_BYTES = 2 * 1024 * 1024
MAX_COVER_SIDE = 400
ALLOWED_IMAGE_FORMATS = {"JPEG": "jpg", "PNG": "png", "WEBP": "webp"}


def seed_demo_data() -> None:
    with SessionLocal() as db:
        demo_users = [
            ("admin", "Дмитрий Волков", "admin", os.getenv("DEMO_ADMIN_PASSWORD", "Admin123!")),
            ("seller", "Анна Смирнова", "seller", os.getenv("DEMO_SELLER_PASSWORD", "Seller123!")),
            ("manager", "Мария Кузнецова", "manager", os.getenv("DEMO_MANAGER_PASSWORD", "Manager123!")),
        ]
        for login, full_name, role, password in demo_users:
            if not db.scalar(select(User).where(User.login == login)):
                db.add(User(login=login, full_name=full_name, role=role, password_hash=hash_password(password)))

        genres = {g.name: g for g in db.scalars(select(Genre)).all()}
        publishers = {p.name: p for p in db.scalars(select(Publisher)).all()}
        fresh_catalog = not genres and not publishers and not db.scalar(select(Book.id).limit(1))
        if not genres:
            genres = {name: Genre(name=name) for name in ("Современная проза", "Детектив", "Научная фантастика")}
            db.add_all(genres.values())
        if not publishers:
            publishers = {name: Publisher(name=name) for name in ("Северное слово", "Литкласс")}
            db.add_all(publishers.values())
        db.flush()
        genres = {g.name: g for g in db.scalars(select(Genre)).all()}
        publishers = {p.name: p for p in db.scalars(select(Publisher)).all()}

        if fresh_catalog:
            today = date.today()
            db.add_all([
                Book(
                    title="Демо: Город на рассвете", description="Новая история о выборе, памяти и большом городе.",
                    genre=genres["Современная проза"], publisher=publishers["Северное слово"], rating=4.8,
                    price=790, publication_date=today - timedelta(days=12), stock=6, format="print",
                ),
                Book(
                    title="Демо: Письма из старого дома", description="Семейная тайна, которая меняет настоящее.",
                    genre=genres["Детектив"], publisher=publishers["Литкласс"], rating=4.4,
                    price=560, publication_date=today - timedelta(days=900), stock=8, format="print",
                ),
                Book(
                    title="Демо: Орбита тишины", description="Электронное издание о первой экспедиции к Европе.",
                    genre=genres["Научная фантастика"], publisher=publishers["Северное слово"], rating=4.9,
                    price=420, publication_date=today - timedelta(days=120), stock=10, format="ebook",
                ),
            ])
        db.flush()

        if fresh_catalog and not db.scalar(select(Order.id).limit(1)):
            customer = Customer(full_name="Елена Морозова", email="elena@example.ru", phone="+7 900 123-45-67")
            second_customer = Customer(full_name="Илья Петров", email="ilya@example.ru", phone="+7 900 765-43-21")
            db.add_all([customer, second_customer])
            db.flush()
            books = db.scalars(select(Book).order_by(Book.id)).all()
            now = datetime.now(timezone.utc)
            overdue = Order(
                order_number="BS-DEMO-001", placed_at=now - timedelta(days=8),
                delivery_date=date.today() - timedelta(days=2), customer=customer, status="processing",
            )
            completed = Order(
                order_number="BS-DEMO-002", placed_at=now - timedelta(days=4),
                delivery_date=date.today() + timedelta(days=2), customer=second_customer, status="shipped",
            )
            db.add_all([overdue, completed])
            db.flush()
            if books:
                db.add_all([
                    OrderItem(order=overdue, book=books[0], quantity=1, unit_price=books[0].price),
                    OrderItem(order=completed, book=books[-1], quantity=2, unit_price=books[-1].price),
                ])
        db.commit()


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(engine)
    seed_demo_data()
    yield


app = FastAPI(title="BookStore", lifespan=lifespan)
app.add_middleware(
    SessionMiddleware,
    secret_key=os.getenv("SECRET_KEY", "development-only-secret-change-before-deploy"),
    session_cookie="bookstore_session",
    same_site="lax",
    https_only=os.getenv("COOKIE_SECURE", "false").lower() == "true",
    max_age=60 * 60 * 12,
)
app.mount("/static", StaticFiles(directory=APP_DIR / "static"), name="static")
templates = Jinja2Templates(directory=APP_DIR / "templates")


def current_user(request: Request) -> dict | None:
    return request.session.get("user")


def require_role(request: Request, *allowed: str) -> dict:
    user = current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Необходим вход в систему")
    if user["role"] not in allowed:
        raise HTTPException(status_code=403, detail="Недостаточно прав для этого действия")
    return user


def render(request: Request, template: str, **context):
    context.update(
        request=request,
        user=current_user(request),
        csrf_token=request.session.setdefault("csrf_token", secrets.token_urlsafe(32)),
        flash=request.session.pop("flash", None),
    )
    return templates.TemplateResponse(request=request, name=template, context=context)


def flash(request: Request, message: str, kind: str = "success") -> None:
    request.session["flash"] = {"message": message, "kind": kind}


def check_csrf(request: Request, token: str) -> None:
    if not valid_csrf(request, token):
        raise HTTPException(status_code=403, detail="Сессия формы устарела. Обновите страницу.")


def parse_book_values(
    title: str,
    description: str,
    genre_id: int,
    publisher_id: int,
    rating: str,
    price: str,
    publication_date: str,
    stock: int,
    book_format: str,
) -> dict:
    title = title.strip()
    if not title:
        raise ValueError("Укажите название книги.")
    try:
        parsed_rating = Decimal(rating.replace(",", "."))
        parsed_price = Decimal(price.replace(",", "."))
        parsed_date = date.fromisoformat(publication_date)
    except (InvalidOperation, ValueError):
        raise ValueError("Проверьте рейтинг, стоимость и дату издания.")
    if not parsed_rating.is_finite() or parsed_rating < 0 or parsed_rating > 5:
        raise ValueError("Рейтинг должен быть от 0 до 5.")
    if not parsed_price.is_finite() or parsed_price < 0:
        raise ValueError("Стоимость не может быть отрицательной.")
    if stock < 0:
        raise ValueError("Количество не может быть отрицательным.")
    if book_format not in {"print", "ebook"}:
        raise ValueError("Выберите формат книги.")
    return {
        "title": title,
        "description": description.strip(),
        "genre_id": genre_id,
        "publisher_id": publisher_id,
        "rating": parsed_rating,
        "price": parsed_price,
        "publication_date": parsed_date,
        "stock": stock,
        "format": book_format,
    }


def save_cover(upload: UploadFile | None) -> tuple[str | None, Path | None]:
    if upload is None or not upload.filename:
        return None, None
    contents = upload.file.read(MAX_COVER_BYTES + 1)
    if len(contents) > MAX_COVER_BYTES:
        raise ValueError("Изображение должно быть не больше 2 МБ.")
    try:
        image = Image.open(io.BytesIO(contents))
        image_format = image.format
        width, height = image.size
        image.verify()
    except (UnidentifiedImageError, Image.DecompressionBombError, OSError, ValueError):
        raise ValueError("Загрузите корректное изображение JPG, PNG или WebP.")
    if image_format not in ALLOWED_IMAGE_FORMATS:
        raise ValueError("Поддерживаются только изображения JPG, PNG и WebP.")
    if width > MAX_COVER_SIDE or height > MAX_COVER_SIDE:
        raise ValueError("Размер обложки не должен превышать 400 × 400 пикселей.")
    filename = f"{secrets.token_hex(12)}.{ALLOWED_IMAGE_FORMATS[image_format]}"
    path = APP_DIR / "static" / "covers" / filename
    path.write_bytes(contents)
    return f"covers/{filename}", path


@app.get("/")
def login_page(request: Request):
    if current_user(request):
        return RedirectResponse("/catalog", status_code=303)
    return render(request, "login.html")


@app.post("/login")
def login(
    request: Request,
    login_name: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    account = db.scalar(select(User).where(User.login == login_name.strip()))
    if not account or not verify_password(password, account.password_hash):
        flash(request, "Неверный логин или пароль.", "error")
        return RedirectResponse("/", status_code=303)
    request.session.clear()
    request.session["user"] = {"id": account.id, "full_name": account.full_name, "role": account.role}
    request.session["csrf_token"] = secrets.token_urlsafe(32)
    return RedirectResponse("/catalog", status_code=303)


@app.post("/guest")
def guest_login(request: Request):
    request.session.clear()
    request.session["user"] = {"id": None, "full_name": "Гость", "role": "guest"}
    request.session["csrf_token"] = secrets.token_urlsafe(32)
    return RedirectResponse("/catalog", status_code=303)


@app.post("/logout")
def logout(request: Request, csrf_token: str = Form(...)):
    check_csrf(request, csrf_token)
    request.session.clear()
    return RedirectResponse("/", status_code=303)


@app.get("/catalog")
def catalog(request: Request, db: Session = Depends(get_db)):
    user = current_user(request)
    if not user:
        return RedirectResponse("/", status_code=303)
    books = db.scalars(
        select(Book)
        .options(joinedload(Book.genre), joinedload(Book.publisher))
        .order_by(Book.publication_date.desc(), Book.id.desc())
    ).all()
    genres = db.scalars(select(Genre).order_by(Genre.name)).all()
    publishers = db.scalars(select(Publisher).order_by(Publisher.name)).all()
    today = date.today()
    try:
        two_year_cutoff = today.replace(year=today.year - 2)
    except ValueError:
        two_year_cutoff = today.replace(year=today.year - 2, day=28)
    rows = []
    payloads = {}
    for book in books:
        age = (today - book.publication_date).days
        rows.append({"book": book, "is_new": 0 <= age < 30, "is_illiquid": book.publication_date < two_year_cutoff and book.stock > 5})
        payloads[book.id] = {
            "title": book.title,
            "description": book.description,
            "genre_id": book.genre_id,
            "publisher_id": book.publisher_id,
            "rating": str(book.rating),
            "price": str(book.price),
            "publication_date": book.publication_date.isoformat(),
            "stock": book.stock,
            "format": book.format,
        }
    today_count = sum(1 for row in rows if row["is_new"])
    in_stock_count = sum(1 for row in rows if row["book"].stock > 0)
    return render(
        request, "catalog.html", rows=rows, genres=genres, publishers=publishers,
        payloads=payloads, can_filter=user["role"] != "guest", is_admin=user["role"] == "admin",
        today_count=today_count, in_stock_count=in_stock_count,
    )


@app.post("/admin/books")
def create_book(
    request: Request,
    title: str = Form(...), description: str = Form(""), genre_id: int = Form(...),
    publisher_id: int = Form(...), rating: str = Form("0"), price: str = Form(...),
    publication_date: str = Form(...), stock: int = Form(0), book_format: str = Form("print"),
    cover: UploadFile | None = File(default=None), csrf_token: str = Form(...),
    db: Session = Depends(get_db),
):
    require_role(request, "admin")
    check_csrf(request, csrf_token)
    saved_path = None
    try:
        values = parse_book_values(title, description, genre_id, publisher_id, rating, price, publication_date, stock, book_format)
        if not db.get(Genre, genre_id) or not db.get(Publisher, publisher_id):
            raise ValueError("Выберите существующий жанр и издательство.")
        cover_path, saved_path = save_cover(cover)
        book = Book(**values, cover_path=cover_path)
        db.add(book)
        db.commit()
        flash(request, "Книга добавлена в каталог.")
    except ValueError as exc:
        db.rollback()
        if saved_path:
            saved_path.unlink(missing_ok=True)
        flash(request, str(exc), "error")
    return RedirectResponse("/catalog", status_code=303)


@app.post("/admin/books/{book_id}")
def update_book(
    book_id: int,
    request: Request,
    title: str = Form(...), description: str = Form(""), genre_id: int = Form(...),
    publisher_id: int = Form(...), rating: str = Form("0"), price: str = Form(...),
    publication_date: str = Form(...), stock: int = Form(0), book_format: str = Form("print"),
    cover: UploadFile | None = File(default=None), csrf_token: str = Form(...),
    db: Session = Depends(get_db),
):
    require_role(request, "admin")
    check_csrf(request, csrf_token)
    book = db.get(Book, book_id)
    if not book:
        raise HTTPException(status_code=404, detail="Книга не найдена")
    saved_path = None
    try:
        values = parse_book_values(title, description, genre_id, publisher_id, rating, price, publication_date, stock, book_format)
        if not db.get(Genre, genre_id) or not db.get(Publisher, publisher_id):
            raise ValueError("Выберите существующий жанр и издательство.")
        cover_path, saved_path = save_cover(cover)
        for key, value in values.items():
            setattr(book, key, value)
        if cover_path:
            book.cover_path = cover_path
        db.commit()
        flash(request, "Изменения книги сохранены.")
    except ValueError as exc:
        db.rollback()
        if saved_path:
            saved_path.unlink(missing_ok=True)
        flash(request, str(exc), "error")
    return RedirectResponse("/catalog", status_code=303)


@app.post("/admin/books/{book_id}/delete")
def delete_book(book_id: int, request: Request, csrf_token: str = Form(...), db: Session = Depends(get_db)):
    require_role(request, "admin")
    check_csrf(request, csrf_token)
    book = db.get(Book, book_id)
    if not book:
        flash(request, "Книга уже удалена.", "error")
        return RedirectResponse("/catalog", status_code=303)
    if db.scalar(select(OrderItem.order_id).where(OrderItem.book_id == book_id).limit(1)):
        flash(request, "Книгу нельзя удалить: она есть в составе заказа.", "error")
        return RedirectResponse("/catalog", status_code=303)
    db.delete(book)
    try:
        db.commit()
        flash(request, "Книга удалена.")
    except IntegrityError:
        db.rollback()
        flash(request, "Книгу нельзя удалить: она есть в составе заказа.", "error")
    return RedirectResponse("/catalog", status_code=303)


@app.get("/orders")
def orders_page(request: Request, db: Session = Depends(get_db)):
    require_role(request, "manager", "admin")
    orders = db.scalars(
        select(Order)
        .options(joinedload(Order.customer), selectinload(Order.items).joinedload(OrderItem.book))
        .order_by(Order.placed_at.desc())
    ).all()
    today = date.today()
    rows = [{"order": order, "overdue": order.delivery_date < today and order.status != "done"} for order in orders]
    return render(request, "orders.html", rows=rows, statuses=ORDER_STATUSES)


@app.post("/orders/{order_id}")
def update_order(
    order_id: int,
    request: Request,
    status: str = Form(...),
    delivery_date: str = Form(...),
    csrf_token: str = Form(...),
    db: Session = Depends(get_db),
):
    require_role(request, "manager", "admin")
    check_csrf(request, csrf_token)
    order = db.get(Order, order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Заказ не найден")
    try:
        new_delivery_date = date.fromisoformat(delivery_date)
        if status not in ORDER_STATUSES:
            raise ValueError
    except ValueError:
        flash(request, "Проверьте статус и плановую дату доставки.", "error")
        return RedirectResponse("/orders", status_code=303)
    order.status = status
    order.delivery_date = new_delivery_date
    db.commit()
    flash(request, f"Заказ {order.order_number} обновлён.")
    return RedirectResponse("/orders", status_code=303)


@app.get("/health")
def health(db: Session = Depends(get_db)):
    db.execute(select(1))
    return {"status": "ok"}
